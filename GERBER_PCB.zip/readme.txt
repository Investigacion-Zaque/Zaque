Project Name: pRACTICAS INVERSTIGATIVAS
Project Version: #dc1884f8
Project Url: https://www.flux.ai/lauritaxd/practicas-inverstigativas~fv

Project Description:
Sistema de adquisicion de datos RS-485 a bateria con ESP32 y control de energia

Project Properties:

Terminal Order:


Software:


Terminal Type:
bidi

Symbol Pin Position:
[object Object]

Manufacturer Part Number:


Manufacturer Name:


Connectivity:


Power Requirements:


Part Type:
Connector

Pin Type:
Unspecified

System Architecture:


Datasheet URL:
[object Object]

License:
https://creativecommons.org/licenses/by/4.0/

Pin Number:
7

Designator Prefix:
J


